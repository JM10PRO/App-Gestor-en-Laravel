<nav class="navbar navbar-expand-lg bg-custom-navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Nosecaen S.L.</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('tareas.index')); ?>">Lista de Tareas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('tareas.create')); ?>">Crear tarea</a>
                </li>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <li class="nav-item">
                      <a href="/logout" class="nav-link" onclick="this.closest('form').submit();">Logout</a>
                    </li>
                </form>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                  </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\app-gestor-laravel\resources\views/components/layouts/navigation.blade.php ENDPATH**/ ?>