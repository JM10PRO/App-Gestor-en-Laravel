<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Tarea '.e($tarea->id).'','metaDescription' => 'Tareas meta description']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Tarea '.e($tarea->id).'','meta-description' => 'Tareas meta description']); ?>

    <h1>Detalles de la tarea <?php echo e($tarea->id); ?></h1>
 
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <td>Id</td>
                    <td>NIF</td>
                    <td>Persona de contacto</td>
                    <td>Teléfono</td>
                    <td>Correo</td>
                    <td>Población</td>
                    <td>Código postal</td>
                    <td>Provincia</td>
                    <td>Dirección</td>
                    <td>Estado</td>
                    <td>Fecha de creación</td>
                    <td>Operario</td>
                    <td>Fecha de realización</td>
                    <td>Anotación anterior</td>
                    <td>Anotación posterior</td>
                    <td>Descripción</td>
                    <td>Fichero resumen</td>
                    <td>Fotos</td>
                    <td>Opciones</td>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <tr>
                    <td><?php echo e($tarea->id); ?></td>
                    <td><?php echo e($tarea->nif); ?></td>
                    <td><?php echo e($tarea->personacontacto); ?></td>
                    <td><?php echo e($tarea->telefono); ?></td>
                    <td><?php echo e($tarea->correo); ?></td>
                    <td><?php echo e($tarea->poblacion); ?></td>
                    <td><?php echo e($tarea->codpostal); ?></td>
                    <td><?php echo e($tarea->provincia); ?></td>
                    <td><?php echo e($tarea->direccion); ?></td>
                    <td><?php echo e($tarea->estado); ?></td>
                    <td><?php echo e($tarea->fechacreacion); ?></td>
                    <td><?php echo e($tarea->operario); ?></td>
                    <td><?php echo e($tarea->fecharealizacion); ?></td>
                    <td><?php echo e($tarea->anotacionanterior); ?></td>
                    <td><?php echo e($tarea->anotacionposterior); ?></td>
                    <td><?php echo e($tarea->descripcion); ?></td>
                    <td><a href="../assets/uploads/<?php echo e($tarea->ficheroresumen); ?>" target="_blank"><?php echo e($tarea->ficheroresumen); ?></a></td>
                    <td><a href="../assets/uploads/<?php echo e($tarea->fotos); ?>" target="_blank"><?php echo e($tarea->fotos); ?></a></td>
                    <td>
                    <td>
                        Acciones
                    </td>
                </tr>
            </tbody>
        </table>
        <div>
        <a title="Volver" class="btn btn-secondary" href="<?php echo e(url()->previous()); ?>">Volver al listado</a>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\app-gestor-laravel\resources\views/tareas/show.blade.php ENDPATH**/ ?>