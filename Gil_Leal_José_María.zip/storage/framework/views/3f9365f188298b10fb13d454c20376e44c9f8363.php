<div class="container-fluid">
    <ul class="nav nav-pills nav-fill" style="--bs-nav-pills-link-active-bg: #fd610d;">
        <a href="" class="navbar-brand">Bunglebuild S.L</a>
    </ul>
</div><?php /**PATH C:\laragon\www\appLaravel\resources\views/titulologin.blade.php ENDPATH**/ ?>