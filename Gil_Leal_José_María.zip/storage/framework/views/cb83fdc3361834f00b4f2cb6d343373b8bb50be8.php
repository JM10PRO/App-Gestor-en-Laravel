<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="<?php echo $__env->yieldContent('meta-description', ''); ?>">
    <meta name="description" content="<?php echo e($metaDescription ?? 'Default meta description'); ?>">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('img/logo-nosecaen.png')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/css/app.scss']); ?>
    <title>Nosecaen S.L. - <?php echo e($title ?? ''); ?></title>
</head>

<body>
    <header>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.navigation','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    </header>

    <section>
        <?php if(session('status')): ?>
        <div class="status">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
    </section>

    <?php echo e($slot); ?>

</body>

</html><?php /**PATH C:\laragon\www\app-gestor-laravel\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>