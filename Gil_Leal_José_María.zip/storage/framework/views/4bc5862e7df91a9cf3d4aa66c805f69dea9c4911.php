<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Tareas','metaDescription' => 'Tareas meta description']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Tareas','meta-description' => 'Tareas meta description']); ?>

    <h1>Listado de Tareas</h1>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <td>Id</td>
                    <!-- <td>NIF</td> -->
                    <td>Persona de contacto</td>
                    <td>Estado de la tarea</td>
                    <td>Operario</td>
                    <td>Fecha de realización</td>
                    <!-- <td>Descripción</td> -->
                    <td>Opciones</td>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tarea->id); ?></td>
                    
                    <td><?php echo e($tarea->personacontacto); ?></td>
                    <td><?php echo e($tarea->estado); ?></td>
                    <td><?php echo e($tarea->operario); ?></td>
                    <td><?php echo e($tarea->fecharealizacion); ?></td>
                    
                    <td>
                        <a title="Detalles" class="btn btn-secondary" href="<?php echo e(route('tareas.show', $tarea)); ?>"><?php echo app('translator')->get('Details'); ?></a>
                        <a title="Detalles" class="btn btn-primary" href="<?php echo e(route('tareas.edit', $tarea)); ?>"><?php echo app('translator')->get('Editar'); ?></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex justify-content-center">
        <?php echo e($tareas->links()); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\app-gestor-laravel\resources\views/tareas/index.blade.php ENDPATH**/ ?>