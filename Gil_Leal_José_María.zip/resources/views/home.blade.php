<x-layouts.app title="Home" meta-description="Home meta description">

    <h1>Home</h1>

    <div class="container">
        {{-- Usuario conectado: {{ Auth::user()->name }} --}}
    </div>

</x-layouts.app>