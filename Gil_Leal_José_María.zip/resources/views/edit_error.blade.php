@extends('_template')

@section('cuerpo')
<h1>Edición</h1>
<div style="background: #ffcccc; margin:1em; border:1px solid #999; border-radius:5px; margin:1em 5em">
    {{$descripcion_error}}
</div>
@endsection


